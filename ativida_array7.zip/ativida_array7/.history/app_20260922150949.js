import { Tecnico } from './model/Tecnico.js';
import {cadastrarInstalacao,cadastrarManutencao,
  cadastrarVistoria,
  associarTecnico,
  listarTodos,
  iniciarServico,
  concluirServico,
  atualizarInstalacao,
  excluirServico
} from './controller/ServicoController.js';

// 1. Criar dois objetos Tecnico (Agregação: criados independentemente)
const tecnico1 = new Tecnico('Carlos Silva', 'Eletromecânica');
const tecnico2 = new Tecnico('Ana Costa', 'Refrigeração');

// 2. Cadastrar uma instalação, uma manutenção e uma vistoria
cadastrarInstalacao(1, 'Empresa Alfa', 'Instalação de Ar Condicionado', 'VRF 60.000 BTUs');
cadastrarManutencao(2, 'Indústria Beta', 'Manutenção Preventiva', 'Ruído excessivo no compressor');
cadastrarVistoria(3, 'Galpão Gama', 'Vistoria Predial de Segurança', 'Setor de Carga e Descarga');

// 3. Associar o mesmo técnico (tecnico1) à instalação (índice 0) e à vistoria (índice 2)
associarTecnico(0, tecnico1);
associarTecnico(2, tecnico1);

// 4. Associar o segundo técnico (tecnico2) à manutenção (índice 1)
associarTecnico(1, tecnico2);

// 5. Listar os serviços
console.log("==> Teste 1: Listagem Inicial dos Serviços");
listarTodos();

// 6. Iniciar um serviço (índice 0) e concluir outro (índice 1)
console.log("==> Teste 2: Iniciar Serviço [0] e Concluir Serviço [1]");
iniciarServico(0);
concluirServico(1);
listarTodos();

// 7. Atualizar um serviço (índice 0) e conferir se manteve o técnico associado
console.log("==> Teste 3: Atualizar Instalação [0] (Verificar preservação do Técnico)");
atualizarInstalacao(0, 1, 'Empresa Alfa', 'Instalação de Ar Condicionado Industrial', 'VRF 80.000 BTUs');
listarTodos();

// 8. Excluir um serviço pelo índice (excluir índice 2 - Vistoria que usava o tecnico1)
console.log("==> Teste 4: Excluir Vistoria [2]");
excluirServico(2);
listarTodos();

// 9. Cadastrar outro serviço e associar a ele o técnico (tecnico1) do serviço excluído
console.log("==> Teste 5: Cadastrar novo serviço e reassociar o Tecnico 1 (Demostração da Agregação)");
cadastrarVistoria(4, 'Shopping Central', 'Vistoria Anual de Incêndio', 'Praça de Alimentação');
associarTecnico(2, tecnico1); // O novo serviço assumiu o índice 2 após a exclusão anterior

// 10. Listar novamente os serviços
console.log("==> Teste Final: Listagem Pós-Reassociação");
listarTodos();