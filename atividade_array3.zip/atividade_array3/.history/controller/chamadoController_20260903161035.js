import { ChamadoHardware } from "../model/ChamadoHardware.js";
import {ChamadoSoftware} from "../model/ChamadoSoftware.js";

import { caadadicionar, editar, deletar, listar, buscarPorIndice } from "../repository/VeiculoRepository.js";

