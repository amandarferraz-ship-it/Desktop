import { pedido } from "../model/pedido.js";
import { agendado } from "../model/pedidoagendado.js";
import { retirada } from "../model/pedidoretirada.js";
import { entrega } from "../model/pedidosentrega.js";