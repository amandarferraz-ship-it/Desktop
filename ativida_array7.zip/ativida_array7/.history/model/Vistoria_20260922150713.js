import { Servico } from './Servico.js';

export class Vistoria extends Servico {
  constructor(codigo, cliente, descricao, local) {
    super(codigo, cliente, descricao);
    this.local = local;
  }

  executar() {
    return `Inspeção e vistoria a ser realizada no local: ${this.local}`;
  }
}