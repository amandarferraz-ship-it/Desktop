const servicos = [];

export function cadastrarServico(servico) {
  servicos.push(servico);
}

export function listarServicos() {
  return servicos;
}

export function buscarServicoPorIndice(indice) {
  return servicos[indice];
}

export function atualizarServico(indice, servico) {
  servicos[indice] = servico;
}

export function deletarServico(indice) {
  servicos.splice(indice, 1);
}