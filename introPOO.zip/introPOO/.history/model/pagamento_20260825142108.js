export class pagamento {
    
}