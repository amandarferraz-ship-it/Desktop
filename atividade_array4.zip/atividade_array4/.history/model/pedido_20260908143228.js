export class Chamado {
#status;
