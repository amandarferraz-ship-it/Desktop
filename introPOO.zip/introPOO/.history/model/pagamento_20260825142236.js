export class pagamento {
    #valor;
    
}