export  class cabecalho {
    constructor(titulo, data) {
    this.titulo = titulo,
    this.data =  data
        
    }
    get pushdata(){
        return this.data;
    }

    get pushtitulo(){
        return this.titulo;
    }

}