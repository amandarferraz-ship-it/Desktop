import { PagamentoCartao } from "./model/pagamentocartao.js";
import { PagamentoPix } from "./model/pagamentoPix.js";
import { Pagamento } from "./model/pagamentoPix.js";


const pagamentoCartao = new PagamentoCartao(
    150,
    123456789

)
const pagamentoPix = new PagamentoPix(
    300,
    "pix@gmail.com"

)

pagamentoCartao.processar();
pagamentoPix.processar();