export class pedido {
    #
}

