import {cabecalho} from ".cabecalho.js";

export class Boletim{
    #status;
    #cabecalho
    #codigo

    constructor(codigo, titulo, data){
        this.#codigo = codigo,
        this.#status = "rascunho";
        this.#cabecalho = new cabecalho(titulo, data);

}

get status(){
    return this.#status;
}

get titulo(){
    return this.#cabecalho.titulo;
}
get data(){
    return this.#cabecalho.data;
}

iniciar() {
            this.#status = "em elaboracao"
        }

 concluir() {
            this.#status = "finalizado"
 }
 apresentar(){
        throw new Error( "O metodo apresentar precisa ser implementado");

        } 
}

