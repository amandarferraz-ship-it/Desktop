const chamados = []

export funt