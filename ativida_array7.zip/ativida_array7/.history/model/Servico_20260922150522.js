export class Servico {
  #status;

  constructor(codigo, cliente, descricao) {
    this.codigo = codigo;
    this.cliente = cliente;
    this.descricao = descricao;
    this.#status = 'agendado';
    this.tecnico = null; // Inicialmente não definido
  }

  get status() {
    return this.#status;
  }

  iniciar() {
    this.#status = 'em andamento';
  }

  concluir() {
    this.#status = 'concluído';
  }

  definirTecnico(tecnico) {
    this.tecnico = tecnico;
  }

  executar() {
    console.log("O método executar() precisa ser implementado pela classe filha.");
  }
}