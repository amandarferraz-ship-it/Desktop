import { Instalacao } from '../model/Instalacao.js';
import { Manutencao } from '../model/Manutencao.js';
import { Vistoria } from '../model/Vistoria.js';
import {cadastrarServico,listarServicos,buscarServicoPorIndice,atualizarServico,deletarServico} from '../repository/ServicoRepository.js';

export function cadastrarInstalacao(codigo, cliente, descricao, equipamento) {
  const servico = new Instalacao(codigo, cliente, descricao, equipamento);
  cadastrarServico(servico);
}

export function cadastrarManutencao(codigo, cliente, descricao, defeito) {
  const servico = new Manutencao(codigo, cliente, descricao, defeito);
  cadastrarServico(servico);
}

export function cadastrarVistoria(codigo, cliente, descricao, local) {
  const servico = new Vistoria(codigo, cliente, descricao, local);
  cadastrarServico(servico);
}

export function associarTecnico(indice, tecnico) {
  const servico = buscarServicoPorIndice(indice);
  if (servico) {
    servico.definirTecnico(tecnico);
  }
}

export function listarTodos() {
  const lista = listarServicos();
  console.log("\n================ AGENDA DE SERVIÇOS_______");
  for (let i = 0; i < lista.length; i++) {
    const s = lista[i];
    const nomeTecnico = s.tecnico ? s.tecnico.nome : "não definido";
    console.log(`Índice: ${i} | Código: ${s.codigo} | Cliente: ${s.cliente} | Status: ${s.status}`);
    console.log(`Descrição: ${s.descricao} | Técnico: ${nomeTecnico}`);
    console.log(`Execução: ${s.executar()}`);
    console.log("----------------------------------------------------");
  }
  console.log("====================================================\n");
}

export function iniciarServico(indice) {
  const servico = buscarServicoPorIndice(indice);
  if (servico) {
    servico.iniciar();
  }
}

export function concluirServico(indice) {
  const servico = buscarServicoPorIndice(indice);
  if (servico) {
    servico.concluir();
  }
}

export function atualizarInstalacao(indice, codigo, cliente, descricao, equipamento) {
  const servicoAntigo = buscarServicoPorIndice(indice);
  const novoServico = new Instalacao(codigo, cliente, descricao, equipamento);
  if (servicoAntigo && servicoAntigo.tecnico) {
    novoServico.definirTecnico(servicoAntigo.tecnico);
  }
  atualizarServico(indice, novoServico);
}

export function atualizarManutencao(indice, codigo, cliente, descricao, defeito) {
  const servicoAntigo = buscarServicoPorIndice(indice);
  const novoServico = new Manutencao(codigo, cliente, descricao, defeito);
  if (servicoAntigo && servicoAntigo.tecnico) {
    novoServico.definirTecnico(servicoAntigo.tecnico);
  }
  atualizarServico(indice, novoServico);
}

export function atualizarVistoria(indice, codigo, cliente, descricao, local) {
  const servicoAntigo = buscarServicoPorIndice(indice);
  const novoServico = new Vistoria(codigo, cliente, descricao, local);
  if (servicoAntigo && servicoAntigo.tecnico) {
    novoServico.definirTecnico(servicoAntigo.tecnico);
  }
  atualizarServico(indice, novoServico);
}

export function excluirServico(indice) {
  deletarServico(indice);
}