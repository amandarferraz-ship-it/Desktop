import { Cabecalho } from './Cabecalho.js';

export class Boletim {
  #codigo;
  #status;
  #cabecalho;

  constructor(codigo, titulo, data) {
    this.#codigo = codigo;
    this.#status = 'rascunho';
    this.#cabecalho = new Cabecalho(titulo, data);
  }

  get codigo() {
    return this.#codigo;
  }

  get status() {
    return this.#status;
  }

  get titulo() {
    return this.#cabecalho.titulo;
  }

  get data() {
    return this.#cabecalho.data;
  }

  iniciar() {
    this.#status = 'em elaboração';
  }

  concluir() {
    this.#status = 'finalizado';
  }

  apresentar() {
    console.log("O método apresentar() precisa ser implementado pela classe filha.");
  }
}