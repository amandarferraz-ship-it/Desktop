import { cadastrarProducao,cadastrarQualidade,cadastrarManutencao, listarTodos, iniciarBoletim, concluirBoletim, atualizarProducao, excluirBoletim} from './controller/BoletimController.js';

cadastrarProducao(101, 'Produção Turno A', '22/09/2026', 1500);
cadastrarQualidade(102, 'Inspeção Linha 2', '22/09/2026', 12);
cadastrarManutencao(103, 'Reparo Prensa H1', '23/09/2026', 'Prensa Hidráulica H1');

console.log("==> Teste 1: Listagem Inicial");
listarTodos();

console.log(" Teste 2: Iniciar Boletim [0]");
iniciarBoletim(0);
listarTodos();

console.log("-> Teste 3: Concluir Boletim [1]");
concluirBoletim(1);
listarTodos();

console.log("==> Teste 4: Atualizar Boletim [0]");
atualizarProducao(0, 101, 'Produção Turno A (Revisado)', '22/09/2026', 1800);
listarTodos();

console.log("==> Teste 5: Excluir Boletim [2]");
excluirBoletim(2);

console.log("==> Teste Final: Listagem Após Exclusão");
listarTodos();