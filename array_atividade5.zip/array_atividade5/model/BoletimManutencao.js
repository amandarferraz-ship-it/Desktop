import { Boletim } from './Boletim.js';

export class BoletimManutencao extends Boletim {
  #equipamentoAtendido;

  constructor(codigo, titulo, data, equipamentoAtendido) {
    super(codigo, titulo, data);
    this.#equipamentoAtendido = equipamentoAtendido;
  }

  get equipamentoAtendido() {
    return this.#equipamentoAtendido;
  }

  apresentar() {
    console.log(`[MANUTENÇÃO] Título: ${this.titulo} | Data: ${this.data} | Status: ${this.status} | Equipamento: ${this.equipamentoAtendido}`);
  }
}