export class pedido {
}

