import { Boletim } from './Boletim.js';

export class BoletimQualidade extends Boletim {
  #itensReprovados;

  constructor(codigo, titulo, data, itensReprovados) {
    super(codigo, titulo, data);
    this.#itensReprovados = itensReprovados;
  }

  get itensReprovados() {
    return this.#itensReprovados;
  }

  apresentar() {
    console.log(`[QUALIDADE] Título: ${this.titulo} | Data: ${this.data} | Status: ${this.status} | Itens Reprovados: ${this.itensReprovados}`);
  }
}