export class Chamado {

