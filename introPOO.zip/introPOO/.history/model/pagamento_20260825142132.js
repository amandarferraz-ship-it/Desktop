export class pagamento {
    #valor;
}