import { Servico } from './Servico.js';

export class Instalacao extends Servico {
  constructor(codigo, cliente, descricao, equipamento) {
    super(codigo, cliente, descricao);
    this.equipamento = equipamento;
  }

  executar() {
    return `Instalação do equipamento: ${this.equipamento}`;
  }
}