import { Tecnico } from './model/Tecnico.js';
import {cadastrarInstalacao,cadastrarManutencao,cadastrarVistoria,associarTecnico,listarTodos,iniciarServico,concluirServico,atualizarInstalacao,excluirServico} from './controller/ServicoController.js';

const tecnico1 = new Tecnico('Carlos Silva', 'Eletromecânica');
const tecnico2 = new Tecnico('Ana Costa', 'Refrigeração');

cadastrarInstalacao(1, 'Empresa Alfa', 'Instalação de Ar Condicionado', 'VRF 60.000 BTUs');
cadastrarManutencao(2, 'Indústria Beta', 'Manutenção Preventiva', 'Ruído excessivo no compressor');
cadastrarVistoria(3, 'Galpão Gama', 'Vistoria Predial de Segurança', 'Setor de Carga e Descarga');

associarTecnico(0, tecnico1);
associarTecnico(2, tecnico1);

associarTecnico(1, tecnico2);

console.log(" Teste 1: Listagem Inicial dos Serviços");
listarTodos();

console.log(" Teste 2: Iniciar Serviço [0] e Concluir Serviço [1]");
iniciarServico(0);
concluirServico(1);
listarTodos();

console.log("==> Teste 3: Atualizar Instalação [0] (Verificar preservação do Técnico)");
atualizarInstalacao(0, 1, 'Empresa Alfa', 'Instalação de Ar Condicionado Industrial', 'VRF 80.000 BTUs');
listarTodos();

console.log("==> Teste 4: Excluir Vistoria [2]");
excluirServico(2);
listarTodos();

console.log("==> Teste 5: Cadastrar novo serviço e reassociar o Tecnico 1 (Demostração da Agregação)");
cadastrarVistoria(4, 'Shopping Central', 'Vistoria Anual de Incêndio', 'Praça de Alimentação');
associarTecnico(2, tecnico1); 

console.log("==> Teste Final: Listagem Pós-Reassociação");
listarTodos();