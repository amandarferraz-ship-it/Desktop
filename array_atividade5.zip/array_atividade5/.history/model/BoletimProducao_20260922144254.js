import { Boletim } from './Boletim.js';

export class BoletimProducao extends Boletim {
  #quantidadeProduzida;

constructor(codigo, titulo, data, quantidadeProduzida) {
  super(codigo, titulo, data); 
  this.#quantidadeProduzida = quantidadeProduzida;
}

  get quantidadeProduzida() {
    return this.#quantidadeProduzida;
  }

  apresentar() {
    console.log(`[PRODUÇÃO] Título: ${this.titulo} | Data: ${this.data} | Status: ${this.status} | Qtd Produzida: ${this.quantidadeProduzida}`);
  }
}
