export class chamado {
        constructor(){
    