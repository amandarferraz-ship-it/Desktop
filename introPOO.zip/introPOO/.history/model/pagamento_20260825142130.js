export class pagamento {
    #valor
}