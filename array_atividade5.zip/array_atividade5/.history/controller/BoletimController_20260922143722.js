import { BoletimProducao } from '../model/BoletimProducao.js';
import { BoletimQualidade } from '../model/BoletimQualidade.js';
import { BoletimManutencao } from '../model/BoletimManutencao.js';
import { cadastrarBoletim, listarBoletins, deletarBoletim, atualizarBoletim } from '../repository/boletimRepository.js';


export function cadastrarProducao(codigo, titulo, data, quantidade) {
  const boletim = new BoletimProducao(codigo, titulo, data, quantidade);
  cadastrarBoletim(boletim);
}

export function cadastrarQualidade(codigo, titulo, data, reprovados) {
  const boletim = new BoletimQualidade(codigo, titulo, data, reprovados);
  cadastrarBoletim(boletim);
}

export function cadastrarManutencao(codigo, titulo, data, equipamento) {
  const boletim = new BoletimManutencao(codigo, titulo, data, equipamento);
  cadastrarBoletim(boletim);
}

export function listarTodos() {
  const lista = listarBoletins();
  console.log("\n--- LISTA DE BOLETINS ---");
  for (let i = 0; i < lista.length; i++) {
    const b = lista[i];
    console.log(`Índice: ${i} | Código: ${b.codigo} | Título: ${b.titulo} | Data: ${b.data} | Status: ${b.status}`);
    b.apresentar();
  }
  console.log("\n");
}

export function atualizarProducao(indice, codigo, titulo, data, quantidade) {
  const boletim = new BoletimProducao(codigo, titulo, data, quantidade);
  atualizarBoletim(indice, boletim);
}

export function atualizarQualidade(indice, codigo, titulo, data, reprovados) {
  const boletim = new BoletimQualidade(codigo, titulo, data, reprovados);
  atualizarBoletim(indice, boletim);
}

export function atualizarManutencao(indice, codigo, titulo, data, equipamento) {
  const boletim = new BoletimManutencao(codigo, titulo, data, equipamento);
  atualizarBoletim(indice, boletim);
}

export function excluirBoletim(indice) {
  deletarBoletim(indice);
}

export function iniciarBoletim(indice) {
  const lista = listarBoletins();
  if (lista[indice]) {
    lista[indice].iniciar();
  }
}

export function concluirBoletim(indice) {
  const lista = listarBoletins();
  if (lista[indice]) {
    lista[indice].concluir();
  }
}