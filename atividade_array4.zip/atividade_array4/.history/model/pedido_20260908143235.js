export class Chamado {
}

