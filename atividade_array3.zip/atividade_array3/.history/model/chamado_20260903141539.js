export class chamado {
    
}